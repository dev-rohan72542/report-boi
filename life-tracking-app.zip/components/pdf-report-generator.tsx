"use client"

import { Document, Page, Text, View, StyleSheet, PDFDownloadLink, Font } from "@react-pdf/renderer"
import { Button } from "@chakra-ui/react"
import { Download } from "react-feather"

Font.register({
  family: "Noto Sans Bengali",
  src: "https://fonts.gstatic.com/s/notosansbengali/v20/Cn-SJsCGWQxOjaGwMQ6fIiMywrNJIky6nvd8BjzVMvJx2mcSPVFpVEqE-6KmsolLudCk8izI0lcPAqvF.woff2",
})

const styles = StyleSheet.create({
  page: {
    flexDirection: "column",
    backgroundColor: "#ffffff",
    padding: 30,
    fontFamily: "Noto Sans Bengali",
  },
  header: {
    marginBottom: 20,
    textAlign: "center",
    borderBottom: 2,
    borderBottomColor: "#3b82f6",
    paddingBottom: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#1f2937",
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 14,
    color: "#6b7280",
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#374151",
    marginBottom: 10,
    backgroundColor: "#f3f4f6",
    padding: 8,
    borderRadius: 4,
  },
  statsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    marginBottom: 15,
  },
  statCard: {
    backgroundColor: "#f9fafb",
    padding: 12,
    borderRadius: 6,
    border: 1,
    borderColor: "#e5e7eb",
    minWidth: "45%",
    marginBottom: 8,
  },
  statLabel: {
    fontSize: 10,
    color: "#6b7280",
    marginBottom: 2,
  },
  statValue: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#1f2937",
  },
  insightCard: {
    backgroundColor: "#ecfdf5",
    padding: 10,
    borderRadius: 6,
    border: 1,
    borderColor: "#d1fae5",
    marginBottom: 8,
  },
  insightText: {
    fontSize: 11,
    color: "#065f46",
  },
  goalCard: {
    backgroundColor: "#fefce8",
    padding: 10,
    borderRadius: 6,
    border: 1,
    borderColor: "#fde047",
    marginBottom: 8,
  },
  goalTitle: {
    fontSize: 12,
    fontWeight: "bold",
    color: "#92400e",
    marginBottom: 4,
  },
  goalProgress: {
    fontSize: 10,
    color: "#78716c",
  },
  footer: {
    marginTop: "auto",
    paddingTop: 20,
    borderTop: 1,
    borderTopColor: "#e5e7eb",
    textAlign: "center",
  },
  footerText: {
    fontSize: 10,
    color: "#9ca3af",
  },
})

interface PDFReportProps {
  monthName: string
  monthlyStats: any
  insights: any[]
  goalAchievements: any[]
}

const PDFReport = ({ monthName, monthlyStats, insights, goalAchievements }: PDFReportProps) => (
  <Document>
    <Page size="A4" style={styles.page}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>জীবন ট্র্যাকিং রিপোর্ট</Text>
        <Text style={styles.subtitle}>{monthName}</Text>
      </View>

      {/* Monthly Overview */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>মাসিক সারসংক্ষেপ</Text>
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>মোট দিন</Text>
            <Text style={styles.statValue}>{monthlyStats.totalDays}</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>কুরআন অধ্যয়ন</Text>
            <Text style={styles.statValue}>{Math.round(monthlyStats.quranStudy / 60)} ঘণ্টা</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>নামাজ (জামাতে)</Text>
            <Text style={styles.statValue}>{monthlyStats.prayersInCongregation}</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>মোট ব্যায়াম</Text>
            <Text style={styles.statValue}>{monthlyStats.totalExercise}</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>কাজের ঘণ্টা</Text>
            <Text style={styles.statValue}>{Math.round(monthlyStats.totalWorkHours / 60)} ঘণ্টা</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>দক্ষতা উন্নয়ন</Text>
            <Text style={styles.statValue}>{Math.round(monthlyStats.skillDevelopment / 60)} ঘণ্টা</Text>
          </View>
        </View>
      </View>

      {/* Insights */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>মাসিক অন্তর্দৃষ্টি</Text>
        {insights.map((insight, index) => (
          <View key={index} style={styles.insightCard}>
            <Text style={styles.insightText}>{insight.message}</Text>
          </View>
        ))}
      </View>

      {/* Goal Achievements */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>লক্ষ্য অর্জন</Text>
        {goalAchievements.slice(0, 6).map((goal, index) => (
          <View key={index} style={styles.goalCard}>
            <Text style={styles.goalTitle}>{goal.category}</Text>
            <Text style={styles.goalProgress}>
              অর্জিত: {goal.achieved} / লক্ষ্য: {goal.target_value} ({goal.percentage.toFixed(1)}%)
            </Text>
          </View>
        ))}
      </View>

      {/* Detailed Breakdown */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>বিস্তারিত বিশ্লেষণ</Text>
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>কুরআন মুখস্থ</Text>
            <Text style={styles.statValue}>{Math.round(monthlyStats.quranMemorization / 60)} ঘণ্টা</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>হাদিস অধ্যয়ন</Text>
            <Text style={styles.statValue}>{Math.round(monthlyStats.hadithStudy / 60)} ঘণ্টা</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>ইসলামী সাহিত্য</Text>
            <Text style={styles.statValue}>{Math.round(monthlyStats.islamicLiterature / 60)} ঘণ্টা</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>যোগাযোগ</Text>
            <Text style={styles.statValue}>{monthlyStats.totalCommunication} বার</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>বিতরণ কার্যক্রম</Text>
            <Text style={styles.statValue}>{monthlyStats.totalDistribution} টি</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>দাওয়াতি দায়িত্ব</Text>
            <Text style={styles.statValue}>{Math.round(monthlyStats.dawaResponsibilities / 60)} ঘণ্টা</Text>
          </View>
        </View>
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>
          রিপোর্ট তৈরি হয়েছে:{" "}
          {new Date().toLocaleDateString("bn-BD", {
            year: "numeric",
            month: "long",
            day: "numeric",
          })}
        </Text>
        <Text style={styles.footerText}>জীবন ট্র্যাকিং অ্যাপ্লিকেশন</Text>
      </View>
    </Page>
  </Document>
)

interface PDFReportGeneratorProps {
  monthName: string
  monthlyStats: any
  insights: any[]
  goalAchievements: any[]
}

export function PDFReportGenerator({ monthName, monthlyStats, insights, goalAchievements }: PDFReportGeneratorProps) {
  return (
    <PDFDownloadLink
      document={
        <PDFReport
          monthName={monthName}
          monthlyStats={monthlyStats}
          insights={insights}
          goalAchievements={goalAchievements}
        />
      }
      fileName={`life-tracker-report-${monthName.replace(" ", "-")}.pdf`}
    >
      {({ blob, url, loading, error }) => (
        <Button variant="outline" disabled={loading}>
          <Download className="h-4 w-4 mr-2" />
          {loading ? "PDF তৈরি হচ্ছে..." : "PDF ডাউনলোড"}
        </Button>
      )}
    </PDFDownloadLink>
  )
}
